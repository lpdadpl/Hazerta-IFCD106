package com.hazerta.richardson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RichardsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
