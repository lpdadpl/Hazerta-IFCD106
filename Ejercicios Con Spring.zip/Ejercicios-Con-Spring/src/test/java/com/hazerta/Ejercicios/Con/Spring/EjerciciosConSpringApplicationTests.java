package com.hazerta.Ejercicios.Con.Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjerciciosConSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
