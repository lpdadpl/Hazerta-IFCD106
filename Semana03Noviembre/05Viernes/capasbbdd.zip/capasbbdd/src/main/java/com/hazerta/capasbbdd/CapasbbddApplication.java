package com.hazerta.capasbbdd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapasbbddApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapasbbddApplication.class, args);
	}

}
