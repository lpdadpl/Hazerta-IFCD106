package com.hazerta.Ejercicio04_DAO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio04DaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
