package com.hazerta.Ejercicio04_DAO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio04DaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio04DaoApplication.class, args);
	}

}
