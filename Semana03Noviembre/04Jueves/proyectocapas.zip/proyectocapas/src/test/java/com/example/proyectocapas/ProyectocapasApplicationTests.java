package com.example.proyectocapas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectocapasApplicationTests {

	@Test
	void contextLoads() {
	}

}
