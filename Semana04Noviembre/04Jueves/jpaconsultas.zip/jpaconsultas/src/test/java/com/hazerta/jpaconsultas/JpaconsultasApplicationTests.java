package com.hazerta.jpaconsultas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaconsultasApplicationTests {

	@Test
	void contextLoads() {
	}

}
