package com.hazerta.jpaconsultas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaconsultasApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaconsultasApplication.class, args);
	}

}
